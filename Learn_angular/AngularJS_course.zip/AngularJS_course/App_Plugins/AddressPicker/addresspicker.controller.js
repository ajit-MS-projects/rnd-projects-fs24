﻿angular.module("umbraco").controller("byte5.addresspickerController", function ($scope, contentResource) {
    $scope.addresspicker =
            {
                label: "Bitte wählen",
                description: '',
                view: 'contentpicker',
                config: {
                    multiPicker: "1",
                    entityType: "Document",
                    startNode: {
                        query: "",
                        type: "content",
                        id: 1096
                    },
                    filter: ""
                }
            };

    var addressList = function () {
        contentResource.getById(1096).then(function (content) {
            contentResource.getChildren(content.id).then(function (childs) {

                $scope.addressList= childs;
                angular.forEach(childs, function (child) {

                    console.log(child);
                }); 
            });
        });
    };  

    addressList();
 });
