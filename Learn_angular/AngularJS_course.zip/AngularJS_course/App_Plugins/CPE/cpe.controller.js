﻿angular.module("umbraco").controller("byte5.cpeController", function ($scope, contentEditingHelper, editorState, $routeParams, entityResource, contentResource, navigationService, $location) {

    $scope.parentId = "1082";

    

    $scope.contentCreate = function () {
        navigationService.syncTree({ tree: 'content', path: ["1073", "1082"], forceReload: false }).then(function (syncArgs) {
            $scope.currentNode = syncArgs;
        });
    };

    //contentResource.getById($routeParams.id)
    //    .then(function (content) {
    //        var props = contentEditingHelper.getAllProps(content);

    //        angular.forEach(props, function (value, key) {
    //            //debugger;
    //            console.log("Number: " + key);
    //            angular.forEach(value, function (v, k) {
    //                console.log("val: " + v + " - key: " + k);
    //                if (k == "alias" && v=="bodyText")
    //                {
    //                    //console.log("Check :-)");
    //                    $scope.myProp = props[key].value;
    //                }
    //            });
    //            console.log("_______________________");
    //        });
            
    //    });
});