﻿namespace SolarSchmiede.WindowsServiceUtils
{
	public class WindowsService
	{
		public string ServiceName { get; set; }
		public string Status { get; set; }
	}
}
